declare module "compression";
declare module "swagger-ui-express";
declare module "yamljs";
